To run any of the two stage methods run execute the script with noise as the argument. For example to run RAD with celebA with 10 % label noise:

python RAD_celebA 0.1

To run the last layer retraining methods like GUW and GDS, execute the script with the dataset as the argument. The scripts will run for all the considered noise levels. For example, to run GDS with celebA:

Python GDS.py celebA