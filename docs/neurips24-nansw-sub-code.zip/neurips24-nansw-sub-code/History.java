//

public class History{
    public static String [][] HISTORY = {
	{"1.0 - ICML24", "Submission code for ICML'24"}
    };

    public static String CURRENT_HISTORY(){
	return "V" + HISTORY[HISTORY.length-1][0] + " : " + HISTORY[HISTORY.length-1][1] + ".";
    }
}
