
domain="abalone"

fullpathdata="/[path]/Generative-Forests-NeurIPS24-code/Datasets/"
fullpathjava="/[path]/Generative-Forests-NeurIPS24-code/"

noise=(5)

trees=(20)
iterations=(500)

modeltype=("gf")
modeltypeparams=("generative_forest")

for ((i=1; i<= 5; i++)); do
    for ((j=0; j<=${#noise[@]} - 1; j++)); do
	dname="\"${domain}\""
	echo ""
	echo "-- test on $domain with parameters (#Iterations = ${iterations[0]}, #Trees = ${trees[0]})"
	Java -Xmx10000m Wrapper --algorithm_category=1 --dataset="${fullpathdata}${domain}"/Set_"${i}"/"${domain}"_impute"${noise[j]}".csv '--dataset_spec={"name": "$dname", "path": "'${fullpathdata}${domain}'/Set_'${i}'/'${domain}'_impute'${noise[j]}'.csv", "label": "Dummy", "task": "Dummy"}' --num_samples=10 --work_dir="${fullpathdata}${domain}"/Set_"${i}"/working_dir --output_samples="${fullpathdata}${domain}"/Set_"${i}"/output_samples/"${domain}"_impute"${noise[j]}"_"${modeltype[0]}"_generated.csv --output_stats="${fullpathdata}${domain}"/Set_"${i}"/results/"${domain}"_impute"${noise[j]}"_generated_examples.stats '--flags={"iterations" : "'${iterations[0]}'", "force_integer_coding" : "true", "force_binary_coding" : "true", "unknown_value_coding" : "NA", "initial_number_of_trees" : "'${trees[0]}'", "type_of_generative_model" : "'${modeltypeparams[0]}'"}'  --impute_missing=true --density_estimation=false
    done
done
