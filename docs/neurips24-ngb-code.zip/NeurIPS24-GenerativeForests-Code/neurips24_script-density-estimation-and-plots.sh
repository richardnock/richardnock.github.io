
domain="circgauss"

fullpathdata="/[path]/Generative-Forests-NeurIPS24-code/Datasets/"
fullpathjava="/[path]/Generative-Forests-NeurIPS24-code/"

trees=(10)
iterations=(200)

modeltype=("gf")
modeltypeparams=("generative_forest")

for ((i=1; i<= 5; i++)); do
    dname="\"${domain}\""
    echo ""
    echo "-- test on $domain with parameters (#Iterations = ${iterations[0]}, #Trees = ${trees[0]})"
    Java -Xmx12000m Wrapper --algorithm_category=1 --dataset="${fullpathdata}${domain}"/Split_"${i}"/"${domain}"_train.csv --dataset_test="${fullpathdata}${domain}"/Split_"${i}"/"${domain}"_test.csv '--dataset_spec={"name": "$dname", "path": "'${fullpathdata}${domain}'/Split_'${i}'/'${domain}'_train.csv", "label": "Dummy", "task": "Dummy"}' --num_samples=1000 --work_dir="${fullpathdata}${domain}"/working_dir --output_samples="${fullpathdata}${domain}"/Split_"${i}"/"${domain}"_"${modeltype[0]}"_generated.csv --output_stats="${fullpathdata}${domain}"/results/"${domain}"_generated_observations.stats '--plot_labels={"X","Y"}' '--flags={"iterations" : "'${iterations[0]}'", "force_integer_coding" : "true", "force_binary_coding" : "true", "unknown_value_coding" : "NA", "initial_number_of_trees" : "'${trees[0]}'", "type_of_generative_model" : "'${modeltypeparams[0]}'", "plot_type" : "data"}'  --impute_missing=false --density_estimation=true
done
