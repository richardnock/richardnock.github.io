// Code for training generative forests and ensembles of generative trees
// REVIEW CODE -- do not share, do not distribute, delete after review process

import java.util.*;
import java.io.*;

/**************************************************************************************************************************************
 * Class Domain
 *****/

public class Domain implements Debuggable{
    public MemoryMonitor myMemoryMonitor;
    Dataset myDS;

    Wrapper myW;

    Domain(Wrapper w){
	myW = w;
	
	myMemoryMonitor = new MemoryMonitor();

	myDS = new Dataset(this);
	myDS.load_features_and_observations();
	
	System.out.println(myDS);
    }
    
    public String memString(){
	return myMemoryMonitor.memString;
    }
}
