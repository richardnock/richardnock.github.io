// Code for training generative forests and ensembles of generative trees
// REVIEW CODE -- do not share, do not distribute, delete after review process

public class History{
    public static String [][] HISTORY = {
	{"1.0", "ICML'24 sub code for paper #5193, do not share, kindly delete after review process"}
    };

    public static String CURRENT_HISTORY(){
	return "V" + HISTORY[HISTORY.length-1][0] + " : " + HISTORY[HISTORY.length-1][1] + ".";
    }
}
